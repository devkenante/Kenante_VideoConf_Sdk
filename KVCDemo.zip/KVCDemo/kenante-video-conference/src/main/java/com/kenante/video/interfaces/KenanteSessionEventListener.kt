package com.kenante.video.interfaces

interface KenanteSessionEventListener {

    fun onSessionClosed()

}