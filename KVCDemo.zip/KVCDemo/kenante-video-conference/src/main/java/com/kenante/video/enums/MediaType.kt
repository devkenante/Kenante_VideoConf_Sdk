package com.kenante.video.enums

enum class MediaType {

    audio,
    video

}