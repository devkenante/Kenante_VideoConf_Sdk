package com.kenante.video.core

import android.util.SparseArray
import androidx.core.util.set
import com.kenante.video.enums.KenanteAudioCodec
import com.kenante.video.enums.KenanteBitrate
import com.kenante.video.enums.KenanteVideoCodec

object KenanteUsers {

    private val users = SparseArray<User>()
    internal val liveUsers = mutableListOf<Int>()

    fun setUserCallParameters(
        id: Int,
        audioCodec: KenanteAudioCodec,
        videoCodec: KenanteVideoCodec,
        bitrate: KenanteBitrate
    ) {
        users[id] = User(audioCodec, videoCodec, bitrate)
    }

    fun getUser(id: Int) : User?{
        return users[id]
    }

    fun setUsersContainer(userIds: Set<Int>) {
        for (each in userIds){
            users[each] = User(KenanteAudioCodec.opus, KenanteVideoCodec.vp9, KenanteBitrate.low)
        }
    }

}

data class User(
    var audioCodec: KenanteAudioCodec = KenanteAudioCodec.opus,
    var videoCodec: KenanteVideoCodec = KenanteVideoCodec.vp8,
    var bitrate: KenanteBitrate = KenanteBitrate.low
)