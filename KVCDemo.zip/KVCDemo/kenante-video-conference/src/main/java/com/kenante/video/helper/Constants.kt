package com.kenante.video.helper

class Constants {

    companion object {
        val KEEP_ALIVE_DURATION = 25000L
        val MAIN_URL = ""
    }

}