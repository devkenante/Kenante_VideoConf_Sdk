package com.example.kenante_janus.enums

enum class UserRoles {

    publisher,
    subscriber

}