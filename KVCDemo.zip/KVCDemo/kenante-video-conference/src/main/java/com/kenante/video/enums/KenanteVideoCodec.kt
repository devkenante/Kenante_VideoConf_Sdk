package com.kenante.video.enums

enum class KenanteVideoCodec {

    vp8,
    vp9

}