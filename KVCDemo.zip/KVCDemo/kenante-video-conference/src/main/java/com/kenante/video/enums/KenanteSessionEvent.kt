package com.kenante.video.enums

enum class KenanteSessionEvent {

    close,

}