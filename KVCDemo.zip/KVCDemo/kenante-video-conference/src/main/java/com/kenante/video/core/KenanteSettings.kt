package com.kenante.video.core

import android.content.Context
import com.kenante.video.helper.Decorators
import java.lang.RuntimeException

class KenanteSettings {

    companion object{
        private var ksInstance: KenanteSettings? = null
        var url: String? = null
        var protocol: String? = null
        var plugin: String? = null
        private var kContext: Context? = null
        fun getInstance(): KenanteSettings {
            if (ksInstance == null) {
                ksInstance = KenanteSettings()
            }
            return ksInstance!!
        }
    }

    fun init(context: Context, janusUrl: String, janusProtocol: String, janusPlugin: String) {
        kContext = context
        if (janusUrl == "")
            throw RuntimeException("Janus url cannot be empty")
        if (janusProtocol == "")
            throw RuntimeException("Janus protocol cannot be empty")
        if (janusPlugin == "")
            throw RuntimeException("Janus plugin cannot be empty")
        url = janusUrl
        protocol = janusProtocol
        plugin = janusPlugin
    }

    fun checkInit() {
        Decorators.requireNonNullInRuntime(kContext, "Kenante init failed. No context provided.")
        Decorators.requireNonNullInRuntime(url, "Kenante url is null. Please initialize Kenante url using KenanteSettings.getInstance().init(url, protocol, plugin)")
        Decorators.requireNonNullInRuntime(protocol, "Kenante protocol is null. Please initialize Kenante protocol using KenanteSettings.getInstance().init(url, protocol, plugin)")
        Decorators.requireNonNullInRuntime(plugin, "Kenante plugin is null. Please initialize Kenante plugin using KenanteSettings.getInstance().init(url, protocol, plugin)")
    }

    fun getContext() : Context?{
        return kContext
    }

}
