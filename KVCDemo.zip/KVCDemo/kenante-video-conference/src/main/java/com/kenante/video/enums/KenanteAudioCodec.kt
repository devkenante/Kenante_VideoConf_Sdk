package com.kenante.video.enums

enum class KenanteAudioCodec {

    opus,

}