package com.kenante.video.enums

enum class UserCallEvent{

    available,
    connected,
    disconnected,
    connection_closed

}