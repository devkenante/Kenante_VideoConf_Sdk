package com.kenante.video.enums

enum class VideoRoomResponse {

    error,
    joining,
    configured,
    unpublished,
    leaving,
    publishers,
    started

}