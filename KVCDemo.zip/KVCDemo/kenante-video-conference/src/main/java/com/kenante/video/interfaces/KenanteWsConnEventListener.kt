package com.kenante.video.interfaces

import org.json.JSONObject
import java.lang.Exception

interface KenanteWsConnEventListener{

    fun onOpen()
    fun onMessage(obj: JSONObject)
    fun onError(ex: Exception)
    fun onClose()

}